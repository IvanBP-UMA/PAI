package notas;

public class EstudianteException extends Exception{
    public EstudianteException(){
        super();
    }

    public EstudianteException(String err){
        super(err);
    }
}
